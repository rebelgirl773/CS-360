package com.example.sydneyprojectthree;

public class MathUtils {

    /**
     * Calculates the area of a rectangle given its length and width.
     *
     * @param length The length of the rectangle.
     * @param width  The width of the rectangle.
     * @return The area of the rectangle.
     */
    public int calculateRectangleArea(int length, int width) {
        // Calculate the area of the rectangle
        int area = length * width;
        return area;
    }
}
