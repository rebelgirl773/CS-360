package com.example.sydneyprojectthree;

import java.util.HashMap;
        import java.util.Scanner;

public class LoginSystem {
    private HashMap<String, String> users; // HashMap to store user information

    public LoginSystem() {
        users = new HashMap<String, String>();
    }

    public void addUser(String username, String password) {
        users.put(username, password); // add user to HashMap
    }

    public boolean checkLogin(String username, String password) {
        if(users.containsKey(username) && users.get(username).equals(password)) {
            return true; // user exists and password matches
        }
        return false; // user does not exist or password does not match
    }

    public static void main(String[] args) {
        LoginSystem loginSystem = new LoginSystem();

        // add some sample users
        loginSystem.addUser("john", "password123");
        loginSystem.addUser("jane", "test123");

        // prompt user for login information
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // check if login is valid
        if(loginSystem.checkLogin(username, password)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid username or password.");
        }
    }
}
