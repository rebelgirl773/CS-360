package com.example.sydneyprojectthree;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager; // Added import statement for SmsManager
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;
    private Button sendSMSButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize send SMS button
        sendSMSButton = findViewById(R.id.sendSMSButton);

        // Set onClickListener for the send SMS button
        sendSMSButton.setOnClickListener(view -> {
            // Check if SMS permissions are granted
            if (checkSMSPermission()) {
                // Permissions granted, send SMS
                sendSMS();
            } else {
                // Request SMS permissions
                requestSMSPermission();
            }
        });
    }

    // Method to check SMS permissions
    private boolean checkSMSPermission() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        return permissionCheck == PackageManager.PERMISSION_GRANTED;
    }

    // Method to request SMS permissions
    private void requestSMSPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS
                sendSMS();
            } else {
                // Permission denied, display a toast message
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to send SMS
    private void sendSMS() {
        // Implement SMS sending functionality
        String phoneNumber = "1234567890"; // Replace with actual phone number
        String message = "Hello from my app!"; // Replace with actual message
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
    }
}
